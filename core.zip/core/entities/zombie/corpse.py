import pygame
import os
from core.data.config import TILE_SIZE, DARK_GRAY
from core.entities.item.item import Item

class Corpse(Item):
    """Lootable corpse container with automatic decay."""

    def __init__(self, name="Dead corpse", capacity=15, image_path=None, pos=(0, 0), decay_ms=160000):
        # Store image_path before super().__init__ or pass it; Item uses it for loading but doesn't store the string.
        super().__init__(name, 'container', capacity=capacity, sprite_file=image_path)
        
        self.image_path = image_path
        self.rect.center = pos
        
        # [FIX] Initialize x and y so the save system can read them
        self.x = self.rect.x
        self.y = self.rect.y
        
        self.spawn_time = pygame.time.get_ticks()
        self.decay_ms = decay_ms
        self.color = DARK_GRAY

    def to_dict(self):
        """Serialize corpse data, including the critical image_path and explicit type flag."""
        data = super().to_dict()
        data['image_path'] = self.image_path
        data['is_corpse'] = True
        return data

    def is_expired(self, now_ms=None):
        """Return True if corpse lifetime exceeded decay_ms."""
        if now_ms is None:
            now_ms = pygame.time.get_ticks()
        return (now_ms - self.spawn_time) > self.decay_ms

    def spill_contents_to_ground(self, items_on_ground, drop_pos=None):
        """Move contained items from this corpse to world items_on_ground.
        If drop_pos provided, place items near that position; otherwise use corpse center.
        """
        if drop_pos is None:
            drop_x, drop_y = self.rect.center
        else:
            drop_x, drop_y = drop_pos
        for it in list(self.inventory):
            try:
                it.rect.center = (drop_x + 4, drop_y + 4)
                # Ensure items spilled also have valid coordinates
                it.x = it.rect.x
                it.y = it.rect.y
            except Exception:
                pass
            items_on_ground.append(it)
        self.inventory.clear()