import random
from core.data.config import GAME_WIDTH, GAME_HEIGHT, TILE_SIZE

def find_free_tile(rect, obstacles, items_on_ground=None, initial_pos=None, max_radius=10):
    """
    Finds a free tile for the given rect, avoiding obstacles.
    If items_on_ground is provided, avoids them too. If None or [], allows stacking.
    Returns the (x, y) coordinates of the free tile, or None if no free tile is found.
    """
    if items_on_ground is None:
        items_on_ground = []

    if initial_pos:
        start_x = (initial_pos[0] // TILE_SIZE) * TILE_SIZE
        start_y = (initial_pos[1] // TILE_SIZE) * TILE_SIZE
    else:
        start_x = random.randint(0, (GAME_WIDTH // TILE_SIZE) - 1) * TILE_SIZE
        start_y = random.randint(0, (GAME_HEIGHT // TILE_SIZE) - 1) * TILE_SIZE

    rect.x = start_x
    rect.y = start_y

    # Check if the initial position is free
    collision = False
    for ob in obstacles:
        if rect.colliderect(ob):
            collision = True
            break
    if not collision:
        for item in items_on_ground:
            if rect.colliderect(item.rect):
                collision = True
                break
    if not collision:
        return (rect.x, rect.y)

    # If not, and we have an initial position, search outwards radially
    if initial_pos:
        for radius in range(1, max_radius + 1): 
            for i in range(-radius, radius + 1):
                for j in range(-radius, radius + 1):
                    if abs(i) < radius and abs(j) < radius:
                        continue

                    rect.x = start_x + i * TILE_SIZE
                    rect.y = start_y + j * TILE_SIZE

                    # Removed the screen-bound check here so it works on massive world maps
                    collision = False
                    for ob in obstacles:
                        if rect.colliderect(ob):
                            collision = True
                            break
                    if not collision:
                        for item in items_on_ground:
                            if rect.colliderect(item.rect):
                                collision = True
                                break
                    
                    if not collision:
                        return (rect.x, rect.y) 

    return None

def find_random_free_tile(rect, obstacles, items_on_ground):
    rect.x = random.randint(0, (GAME_WIDTH // TILE_SIZE) - 1) * TILE_SIZE
    rect.y = random.randint(0, (GAME_HEIGHT // TILE_SIZE) - 1) * TILE_SIZE

    attempts = 0
    max_attempts = (GAME_WIDTH // TILE_SIZE) * (GAME_HEIGHT // TILE_SIZE)

    while attempts < max_attempts:
        collision = False
        for ob in obstacles:
            if rect.colliderect(ob):
                collision = True
                break
        if not collision:
            for item in items_on_ground:
                if rect.colliderect(item.rect):
                    collision = True
                    break
        
        if not collision:
            return (rect.x, rect.y)

        rect.x += TILE_SIZE
        if rect.x >= GAME_WIDTH:
            rect.x = 0
            rect.y += TILE_SIZE
            if rect.y >= GAME_HEIGHT:
                rect.y = 0
        
        attempts += 1

    return None